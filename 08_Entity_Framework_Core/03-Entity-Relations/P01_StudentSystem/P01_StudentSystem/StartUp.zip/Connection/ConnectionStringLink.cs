﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P01_StudentSystem.Connection
{
    internal static class ConnectionStringLink
    {
        public const string ConnectionString = "Server=localhost;Database=StudentSystem;User Id=sa;Password=Ajfela8569;TrustServerCertificate=True;";
    }
}
