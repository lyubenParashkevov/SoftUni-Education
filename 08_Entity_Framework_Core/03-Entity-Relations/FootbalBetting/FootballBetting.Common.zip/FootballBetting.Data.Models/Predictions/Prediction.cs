﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P02_FootballBetting.Data.Models.Predictions
{
    public enum Prediction
    {
        Home = 1,
        Away = 2,
        Draw = 3,
    }
}
