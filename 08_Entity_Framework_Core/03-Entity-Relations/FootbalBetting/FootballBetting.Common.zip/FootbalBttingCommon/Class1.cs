﻿namespace FootbalBttingCommon
{
    public class Class1
    {

    }
}
