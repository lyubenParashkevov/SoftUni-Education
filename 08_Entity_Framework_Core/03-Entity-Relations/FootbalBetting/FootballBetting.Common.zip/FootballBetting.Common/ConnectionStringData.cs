﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P02_FootballBetting.Common
{
    public static class ConnectionStringData
    {
        public const string ConnectionString = @"Server=localhost;Database=FootballBetting2025;User Id=sa;Password=Ajfela8569;TrustServerCertificate=True;";
    }
}
