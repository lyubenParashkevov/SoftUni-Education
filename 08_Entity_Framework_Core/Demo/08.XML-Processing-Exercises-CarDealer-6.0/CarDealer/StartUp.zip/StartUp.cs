﻿using CarDealer.Data;
using CarDealer.DTOs.Import;
using CarDealer.Models;
using CarDealer.Utilities;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Linq;

namespace CarDealer
{
    public class StartUp
    {
        public static void Main()
        {
            using CarDealerContext db = new CarDealerContext();
            db.Database.Migrate();
            string path = File.ReadAllText("../../../Datasets/parts.xml");

            Console.WriteLine(ImportParts(db, path));


        }


        public static string ImportSuppliers(CarDealerContext context, string inputXml)
        {

            ImportSupplierDto[]? importSupplierDtos = XmlHelper.Deserialize<ImportSupplierDto[]>(inputXml, "Suppliers");
            ICollection<Supplier> suppliersToImport = new List<Supplier>();

            if (importSupplierDtos != null)
            {

                foreach (var supplier in importSupplierDtos)
                {
                    if (!IsValid(supplier))
                    {
                        continue;
                    }

                    bool isImporterDto = bool.TryParse(supplier.IsImporter, out bool isImporter);
                    if (!isImporterDto)
                    {
                        continue;
                    }

                    Supplier supplierToAdd = new Supplier()
                    {
                        Name = supplier.Name,
                        IsImporter = isImporter,
                    };

                    suppliersToImport.Add(supplierToAdd);

                }

                context.Suppliers.AddRange(suppliersToImport);
                context.SaveChanges();
            }

            return $"Successfully imported {suppliersToImport.Count}";

        }

        public static string ImportParts(CarDealerContext context, string inputXml)
        {
            ImportPartDto[]? importPartDtos = XmlHelper.Deserialize<ImportPartDto[]>(inputXml, "Parts");
            ICollection<Part> partsToImport = new List<Part>();

            if (importPartDtos != null)
            {
                foreach (var partDto in importPartDtos)
                {
                    ICollection<int> validSupplierIds = context.Suppliers
                            .Select(x => x.Id)
                            .ToList();

                    if (!IsValid(partDto))
                    {
                        continue;
                    }

                    bool isValidPrice = decimal.TryParse(partDto.Price, out decimal parsedPrice);
                    bool isValidQuantity = int.TryParse(partDto.Quantity, out int parsedQuantity);
                    bool isValidSupplierId = int.TryParse(partDto.SupplierId, out int parsedSupplierId);

                    if (!isValidPrice || !isValidQuantity || !isValidSupplierId)
                    {
                        continue;
                    }

                    if (validSupplierIds.Contains(parsedSupplierId))
                    {
                        Part part = new Part()
                        {
                            Name = partDto.Name,
                            Price = parsedPrice,
                            Quantity = parsedQuantity,
                            SupplierId = parsedSupplierId,
                        };

                        partsToImport.Add(part);
                    }
                }

                context.Parts.AddRange(partsToImport);
                context.SaveChanges();
            }

            return $"Successfully imported {partsToImport.Count}";

        }


        private static bool IsValid(object dto)
        {
            var validateContext = new ValidationContext(dto);
            var validationResults = new List<ValidationResult>();

            bool isValid = Validator
                .TryValidateObject(dto, validateContext, validationResults, true);

            return isValid;
        }
    }
}