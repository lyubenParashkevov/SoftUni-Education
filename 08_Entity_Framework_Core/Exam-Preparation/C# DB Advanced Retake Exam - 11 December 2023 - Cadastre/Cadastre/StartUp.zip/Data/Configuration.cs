﻿namespace Cadastre.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=.;Database=Cadastre;Integrated Security=True;Encrypt=False";
    }
}
