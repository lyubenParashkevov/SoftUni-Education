﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TravelAgency.Data.Models.Enums
{
    public enum Language
    {
        English = 0,
        German = 1, 
        French = 2, 
        Spanish = 3, 
        Russian = 4
    }
}
