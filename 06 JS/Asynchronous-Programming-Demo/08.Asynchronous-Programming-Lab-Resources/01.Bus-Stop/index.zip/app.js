function getInfo() {
    // TODO:
}