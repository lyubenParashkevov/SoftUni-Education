﻿
using _04.BorderControl.Core;

Engine engine = new Engine();
engine.Run();
