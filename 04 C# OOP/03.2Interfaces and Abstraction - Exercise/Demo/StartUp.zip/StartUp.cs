﻿
using Demo.Core;

Engine engine = new Engine();
engine.Run();