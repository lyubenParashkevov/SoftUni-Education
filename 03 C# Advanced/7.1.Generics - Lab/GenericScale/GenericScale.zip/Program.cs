﻿namespace GenericScale
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            EqualityScale<string> nums = new EqualityScale<string>("2", "2");

            Console.WriteLine(nums.Equals());
        }
    }
}