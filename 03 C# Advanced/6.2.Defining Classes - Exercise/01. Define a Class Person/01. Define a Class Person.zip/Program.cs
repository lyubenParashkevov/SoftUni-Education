﻿

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main()
        {
            Person person = new Person("Peter", 46);

            Console.WriteLine(person.Name);
            Console.WriteLine(person.Age);
        }
    }
}