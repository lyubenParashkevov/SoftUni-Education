﻿

namespace CarManufacturer
{
    public class StarтUp
    {
        static void Main()
        {

            Tire[] tires = new Tire[4]
            {
                      new Tire(1, 2.5),
                      new Tire(1, 2.1),
                      new Tire(2, 0.5),
                      new Tire(2, 2.3),
            };

            Engine engine = new Engine(560, 6300);

            Car car = new Car("VW", "Golf", 2025, 200, 10, engine, tires);

            car.Drive(20);
            Console.WriteLine(car.WhoAmI());
          
        }
    }

}